import './App.css';
import LoginForm from './component/LoginForm/LoginForm';
import MathOperation from './component/MathOperation/MathOperation';
import Name from './component/StudentInformation/Name';
import Section from './component/StudentInformation/Section';

function App() {
  const studentInfo = {
    fname: "Adrian",
    mname: "R",
    lname: "Mendoza",
    sect: "BSIT-3B"
  }
  return (
    <div className="App">
      <Name firstname={studentInfo.fname} middlename={studentInfo.mname} lastname={studentInfo.lname}/>
      <Section section={studentInfo.sect}/>
      <LoginForm fname  ={studentInfo.fname} mname={studentInfo.mname} lname={studentInfo.lname} sect={studentInfo.sect}/>
      <MathOperation/>
    </div>
  );
}

export default App;
