import React, { useState } from 'react';
import './MathOperation.css'; // Import the CSS file

const Calculator = () => {
  const [num1, setNum1] = useState('');
  const [num2, setNum2] = useState('');
  const [answer, setAnswer] = useState('');
  const [operation, setOperation] = useState('');

  const handleCalculation = (op) => {
    const number1 = parseFloat(num1);
    const number2 = parseFloat(num2);
    let res = '';

    switch (op) {
      case 'add':
        res = number1 + number2;
        break;
      case 'subtract':
        res = number1 - number2;
        break;
      case 'multiply':
        res = number1 * number2;
        break;
      case 'divide':
        res = number2 !== 0 ? number1 / number2 : 'Cannot divide by zero';
        break;
      default:
        res = 'Select an operation';
    }

    setAnswer(res);
    setOperation(op === 'add' ? 'Addition' : op === 'subtract' ? 'Subtraction' : op === 'multiply' ? 'Multiplication' : 'Division');
  };

  return (
    <div className="login-container">
      <div className="calculator-input">
        
        <input
          type="number"
          value={num1}
          onChange={(e) => setNum1(e.target.value)}
          placeholder="Enter first number"
        />
        <p className="operation">{operation}</p>
        <input
          type="number"
          value={num2}
          onChange={(e) => setNum2(e.target.value)}
          placeholder="Enter second number"
        />
        <p className="equal-sign">=</p>
        <input
          type="text"
          value={answer}
          readOnly
          placeholder="Answer"
          className="answer"
        />
      </div>
      <div style={{ display: 'flex', justifyContent: 'center', gap: '10px' }}>
        <button onClick={() => handleCalculation('add')}>Addition</button>
        <button onClick={() => handleCalculation('subtract')}>Subtraction</button>
        <button onClick={() => handleCalculation('multiply')}>Multiplication</button>
        <button onClick={() => handleCalculation('divide')}>Division</button>
      </div>
    </div>
  );
};

export default Calculator;
