import React, { useState, useRef, useCallback, useContext, createContext } from 'react';
import './LoginForm.css';
import Profile from '../Profile/Profile'; // Importing the Profile component correctly

const ProfileContext = createContext();

function LoginForm({ fname, mname, lname, sect }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const usernameRef = useRef(null);
  const passwordRef = useRef(null);

  const handleLogin = useCallback(
    (e) => {
      e.preventDefault();
      if (username === 'username' && password === 'password') {
        setIsLoggedIn(true);
      } else {
        alert('Invalid credentials');
      }
    },
    [username, password]
  );

  const handleShowPassword = useCallback(() => {
    setShowPassword(!showPassword);
  }, [showPassword]);

  const handleLogout = useCallback(() => {
    setIsLoggedIn(false);
    setUsername(''); // Clear the username
    setPassword(''); // Clear the password
  }, []);

  return (
    <ProfileContext.Provider value={{ fname, mname, lname, sect, username, isLoggedIn }}>
      <div className="login-container">
        <h2>{isLoggedIn ? 'Profile' : 'Login'}</h2>
        {!isLoggedIn ? (
          <form onSubmit={handleLogin}>
            <div>
              <label htmlFor="username">Username</label>
              <input
                type="text"
                id="username"
                ref={usernameRef}
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Username"
                required
              />
            </div>
            <div>
              <label htmlFor="password">Password</label>
              <input
                type={showPassword ? 'text' : 'password'}
                id="password"
                ref={passwordRef}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Password"
                required
              />
              <label>
                <input
                  type="checkbox"
                  checked={showPassword}
                  onChange={handleShowPassword}
                />
                Show Password
              </label>
            </div>
            <button type="submit">Login</button>
          </form>
        ) : (
          <ProfileInfo onLogout={handleLogout} />
        )}
      </div>
    </ProfileContext.Provider>
  );
}

function ProfileInfo({ onLogout }) {
  const { fname, mname, lname, sect } = useContext(ProfileContext);

  return (
    <div>
      <Profile firstname={fname} middlename={mname} lastname={lname} section={sect} />
      <button onClick={onLogout}>Logout</button>
    </div>
  );
}

export default LoginForm;
