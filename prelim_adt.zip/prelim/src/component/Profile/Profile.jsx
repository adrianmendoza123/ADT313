import './Profile.css';
function Profile({firstname, middlename, lastname, section}) {
    return(
        <div>
            <p>Firstname: {firstname}</p>
            <p>Middlename: {middlename}</p>
            <p>Lastname: {lastname}</p>
            <p>Section: {section}</p>
            
        </div>
    )
}

export default Profile;